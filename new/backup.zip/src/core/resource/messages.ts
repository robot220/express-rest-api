/// <reference path="../utils/a.ts" />
/// <reference path="../utils/b.ts" />

import * as test from './ns';

let t1 = new Utils.A();
let t2 = new Utils.B();