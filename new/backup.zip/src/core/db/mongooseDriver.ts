import mongooseCfg from '../../config/mongoose';
const mongoose = require('mongoose');
//import * as mongoose from "mongoose";

export default class MongooseDB {
    private connectionString: string;
    constructor(){
        this.connectionString = mongooseCfg.getConnection();
        mongoose.Promise = global.Promise;
        //(mongoose as any).Promise = global.Promise;
    }
    public connect(connection: string = this.connectionString): void {        
        mongoose.connect(connection)
            .then(() => console.log('connection to DB is successful') )
            .catch((err) => console.error(err));
    }
}