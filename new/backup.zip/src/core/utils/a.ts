module Utils {
    export class A {
        constructor(){
            console.log("A");
        }
    }
}