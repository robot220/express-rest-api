/// <reference path="a.ts" />

module Utils {
    export class B {
        constructor(){
            console.log("B");
        }
    }
}