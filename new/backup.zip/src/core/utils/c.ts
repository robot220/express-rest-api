namespace TestNS {
    
    export class AA {
        constructor(){
            console.log("AA");
        }
    }
    
}