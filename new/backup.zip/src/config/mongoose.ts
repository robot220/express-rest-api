export default class MongooseCfg {
    public static domain : string = "localhost";
    public static port : number = 27017;
    //public static dbName : string = "express-simple-api";
    public static dbName : string = "test";
    public static getConnection(): string {
        let connection = `mongodb://${this.domain}:${this.port}/${this.dbName}`;
        console.log( connection );
        return connection;
    }
}