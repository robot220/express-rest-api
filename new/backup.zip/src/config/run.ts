import "reflect-metadata";
import {useExpressServer} from "routing-controllers";
import "../controllers/UserController";
import "../middlewares/AllErrorsHandler";

export function runServer(port: number = 3002){
    const app = require("../config/express").default();
    useExpressServer(app, {
        routePrefix: "/api",
        //controllers: [__dirname + "controllers/*{.ts}"]
    }).listen(port);
    console.log(`Server running at http://localhost:${port}/`);
}