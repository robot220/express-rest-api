const mongoose = require('mongoose');
//import * as mongoose from "mongoose";

const UserSchema = new mongoose.Schema({
    name: String
});
module.exports = mongoose.model('User', UserSchema);