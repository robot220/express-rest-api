import * as http from "http";
import config from "./config/config";


// Init the express application
/*
const app = require("./config/express").default();

const server: http.Server = http.createServer(app);

server.listen(config.port);

server.on("error", (e : Error) => {
  console.log("Error starting server" + e);
});

server.on("listening", () => {
  console.log("Server started on port " + config.port);
});*/

/*
import "es6-shim";
import "reflect-metadata";
import {useExpressServer} from "routing-controllers";
import "./controllers/UserController";

const app = require("./config/express").default();
useExpressServer(app, {
  routePrefix: "/api",
  controllers: [__dirname + "controllers/!*{.ts}"]
}).listen(3002);
console.log('Server running at http://localhost:3002/');*/

import { runServer } from './config/run';
runServer();
