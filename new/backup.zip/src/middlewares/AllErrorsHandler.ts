import {MiddlewareGlobalBefore, ErrorMiddlewareInterface} from "routing-controllers";

@MiddlewareGlobalBefore()
export class AllErrorsHandler implements ErrorMiddlewareInterface {

    error(error: any, request: any, response: any, next?: Function): void {
        console.log("Error handled: ", error);
        response.send(error.status);
        next(error);
    }

}