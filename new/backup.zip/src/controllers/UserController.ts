import {JsonController, Header, Param, Body, Req, Res, Get, Post, Put, Delete} from "routing-controllers";
import {Request, Response} from "express";
import async = Q.async;
import {HttpError} from "routing-controllers/error/http/HttpError";
const User = require('../models/User');

const request = require("request");

@JsonController("/users")
export class UserController {

    @Get("/")
    async getAll(@Req() request: Request, @Res() response: Response) {
        await User.find({}, (err, users) => {
            if (err) { /*...*/ }
            response.header("Test", "2");
            response.status(200).json(users);
        });

        //const a = 10;
        //if (a == 20) { throw new HttpError(400, "Incorrect password.") }
        /*response.status(200).json(getData());*/


        /*return new Promise<void>(resolve => {
            User.find({}, (err, users) => {
                response.status(200).json(users);
            });
        });*/

        /*User.find({}).then((users) => {
            console.log(users);
        });
        return f2(10, 20);*/

        /*User.find({"name": "Bob"}, function(err, data){
            return response.send(data).end();
        });
        return 20;*/

        /*User.find({}, (err, users) => {
            response.header("Test", "2");
            response.status(200).send("All is ok").end();
        });*/

    }

    @Post("/")
    async post(@Body({ required: true }) user: any, @Req() request: Request, @Res() response: Response) {
        await User.create({"name": user.name}, (err, data) => {
            response.header("ResultHeader", "All is ok");
            response.status(200).json(`User with name "${user.name}" was created.`);
        });
    }

    /*@Post("/mock")
    postMock() {
        request.post('http://localhost:3002/api/users').form(
            {name: 'Tom'}
        )
    }*/


    /*@Get("/:id")
    getOne(@Param("id") id: number) {
        return "This action returns user #" + id;
    }

    @Post("/")
    post(@Body() user: any) {
        return "Saving user...";
    }

    @Put("/:id")
    put(@Param("id") id: number, @Body() user: any) {
        return "Updating a user...";
    }

    @Delete("/:id")
    remove(@Param("id") id: number) {
        return "Removing user...";
    }*/

}

async function f2(): PromiseLike<any> {

}