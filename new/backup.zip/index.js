'use strict';
require('ts-node/register');
require('./src');